package com.getkeepsafe.relinker;

import android.content.Context;
import android.content.pm.ApplicationInfo;
import com.getkeepsafe.relinker.ReLinker;
import java.io.Closeable;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;

public class ApkLibraryInstaller implements ReLinker.LibraryInstaller {
    private static final int COPY_BUFFER_SIZE = 4096;
    private static final int MAX_TRIES = 5;

    private String[] sourceDirectories(Context context) {
        ApplicationInfo applicationInfo = context.getApplicationInfo();
        if (applicationInfo.splitSourceDirs == null || applicationInfo.splitSourceDirs.length == 0) {
            return new String[]{applicationInfo.sourceDir};
        }
        String[] strArr = new String[(applicationInfo.splitSourceDirs.length + 1)];
        strArr[0] = applicationInfo.sourceDir;
        System.arraycopy(applicationInfo.splitSourceDirs, 0, strArr, 1, applicationInfo.splitSourceDirs.length);
        return strArr;
    }

    private static class ZipFileInZipEntry {
        public ZipEntry zipEntry;
        public ZipFile zipFile;

        public ZipFileInZipEntry(ZipFile zipFile2, ZipEntry zipEntry2) {
            this.zipFile = zipFile2;
            this.zipEntry = zipEntry2;
        }
    }

    private ZipFileInZipEntry findAPKWithLibrary(Context context, String[] strArr, String str, ReLinkerInstance reLinkerInstance) {
        String[] strArr2 = strArr;
        ZipFile zipFile = null;
        for (String str2 : sourceDirectories(context)) {
            int i = 0;
            while (true) {
                int i2 = i + 1;
                if (i >= 5) {
                    break;
                }
                try {
                    zipFile = new ZipFile(new File(str2), 1);
                    break;
                } catch (IOException unused) {
                    i = i2;
                }
            }
            if (zipFile == null) {
                String str3 = str;
                ReLinkerInstance reLinkerInstance2 = reLinkerInstance;
            } else {
                int i3 = 0;
                while (true) {
                    int i4 = i3 + 1;
                    if (i3 < 5) {
                        int length = strArr2.length;
                        for (int i5 = 0; i5 < length; i5++) {
                            String str4 = "lib" + File.separatorChar + strArr2[i5] + File.separatorChar + str;
                            reLinkerInstance.log("Looking for %s in APK %s...", str4, str2);
                            ZipEntry entry = zipFile.getEntry(str4);
                            if (entry != null) {
                                return new ZipFileInZipEntry(zipFile, entry);
                            }
                        }
                        String str5 = str;
                        ReLinkerInstance reLinkerInstance3 = reLinkerInstance;
                        i3 = i4;
                    } else {
                        String str6 = str;
                        ReLinkerInstance reLinkerInstance4 = reLinkerInstance;
                        try {
                            zipFile.close();
                            break;
                        } catch (IOException unused2) {
                        }
                    }
                }
            }
        }
        return null;
    }

    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r0v1, resolved type: com.getkeepsafe.relinker.ApkLibraryInstaller$ZipFileInZipEntry} */
    /* JADX WARNING: type inference failed for: r0v0 */
    /* JADX WARNING: type inference failed for: r0v2 */
    /* JADX WARNING: type inference failed for: r0v3, types: [java.io.Closeable] */
    /* JADX WARNING: type inference failed for: r0v4 */
    /* JADX WARNING: Multi-variable type inference failed */
    /* JADX WARNING: Removed duplicated region for block: B:70:0x00a6 A[SYNTHETIC, Splitter:B:70:0x00a6] */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void installLibrary(android.content.Context r9, java.lang.String[] r10, java.lang.String r11, java.io.File r12, com.getkeepsafe.relinker.ReLinkerInstance r13) {
        /*
            r8 = this;
            r0 = 0
            com.getkeepsafe.relinker.ApkLibraryInstaller$ZipFileInZipEntry r9 = r8.findAPKWithLibrary(r9, r10, r11, r13)     // Catch:{ all -> 0x00a3 }
            if (r9 == 0) goto L_0x009a
            r10 = 0
            r1 = r10
        L_0x0009:
            int r2 = r1 + 1
            r3 = 5
            if (r1 >= r3) goto L_0x0089
            java.lang.String r1 = "Found %s! Extracting..."
            java.lang.Object[] r3 = new java.lang.Object[]{r11}     // Catch:{ all -> 0x00a0 }
            r13.log(r1, r3)     // Catch:{ all -> 0x00a0 }
            boolean r1 = r12.exists()     // Catch:{ IOException -> 0x0087 }
            if (r1 != 0) goto L_0x0025
            boolean r1 = r12.createNewFile()     // Catch:{ IOException -> 0x0087 }
            if (r1 != 0) goto L_0x0025
            goto L_0x0087
        L_0x0025:
            java.util.zip.ZipFile r1 = r9.zipFile     // Catch:{ FileNotFoundException -> 0x0081, IOException -> 0x007b, all -> 0x0072 }
            java.util.zip.ZipEntry r3 = r9.zipEntry     // Catch:{ FileNotFoundException -> 0x0081, IOException -> 0x007b, all -> 0x0072 }
            java.io.InputStream r1 = r1.getInputStream(r3)     // Catch:{ FileNotFoundException -> 0x0081, IOException -> 0x007b, all -> 0x0072 }
            java.io.FileOutputStream r3 = new java.io.FileOutputStream     // Catch:{ FileNotFoundException -> 0x0070, IOException -> 0x006e, all -> 0x006a }
            r3.<init>(r12)     // Catch:{ FileNotFoundException -> 0x0070, IOException -> 0x006e, all -> 0x006a }
            long r4 = r8.copy(r1, r3)     // Catch:{ FileNotFoundException -> 0x0083, IOException -> 0x007d, all -> 0x0068 }
            java.io.FileDescriptor r6 = r3.getFD()     // Catch:{ FileNotFoundException -> 0x0083, IOException -> 0x007d, all -> 0x0068 }
            r6.sync()     // Catch:{ FileNotFoundException -> 0x0083, IOException -> 0x007d, all -> 0x0068 }
            long r6 = r12.length()     // Catch:{ FileNotFoundException -> 0x0083, IOException -> 0x007d, all -> 0x0068 }
            int r4 = (r4 > r6 ? 1 : (r4 == r6 ? 0 : -1))
            if (r4 == 0) goto L_0x004c
            r8.closeSilently(r1)     // Catch:{ all -> 0x00a0 }
        L_0x0048:
            r8.closeSilently(r3)     // Catch:{ all -> 0x00a0 }
            goto L_0x0087
        L_0x004c:
            r8.closeSilently(r1)     // Catch:{ all -> 0x00a0 }
            r8.closeSilently(r3)     // Catch:{ all -> 0x00a0 }
            r11 = 1
            r12.setReadable(r11, r10)     // Catch:{ all -> 0x00a0 }
            r12.setExecutable(r11, r10)     // Catch:{ all -> 0x00a0 }
            r12.setWritable(r11)     // Catch:{ all -> 0x00a0 }
            if (r9 == 0) goto L_0x0067
            java.util.zip.ZipFile r10 = r9.zipFile     // Catch:{ IOException -> 0x0067 }
            if (r10 == 0) goto L_0x0067
            java.util.zip.ZipFile r9 = r9.zipFile     // Catch:{ IOException -> 0x0067 }
            r9.close()     // Catch:{ IOException -> 0x0067 }
        L_0x0067:
            return
        L_0x0068:
            r10 = move-exception
            goto L_0x006c
        L_0x006a:
            r10 = move-exception
            r3 = r0
        L_0x006c:
            r0 = r1
            goto L_0x0074
        L_0x006e:
            r3 = r0
            goto L_0x007d
        L_0x0070:
            r3 = r0
            goto L_0x0083
        L_0x0072:
            r10 = move-exception
            r3 = r0
        L_0x0074:
            r8.closeSilently(r0)     // Catch:{ all -> 0x00a0 }
            r8.closeSilently(r3)     // Catch:{ all -> 0x00a0 }
            throw r10     // Catch:{ all -> 0x00a0 }
        L_0x007b:
            r1 = r0
            r3 = r1
        L_0x007d:
            r8.closeSilently(r1)     // Catch:{ all -> 0x00a0 }
            goto L_0x0048
        L_0x0081:
            r1 = r0
            r3 = r1
        L_0x0083:
            r8.closeSilently(r1)     // Catch:{ all -> 0x00a0 }
            goto L_0x0048
        L_0x0087:
            r1 = r2
            goto L_0x0009
        L_0x0089:
            java.lang.String r10 = "FATAL! Couldn't extract the library from the APK!"
            r13.log((java.lang.String) r10)     // Catch:{ all -> 0x00a0 }
            if (r9 == 0) goto L_0x0099
            java.util.zip.ZipFile r10 = r9.zipFile     // Catch:{ IOException -> 0x0099 }
            if (r10 == 0) goto L_0x0099
            java.util.zip.ZipFile r9 = r9.zipFile     // Catch:{ IOException -> 0x0099 }
            r9.close()     // Catch:{ IOException -> 0x0099 }
        L_0x0099:
            return
        L_0x009a:
            com.getkeepsafe.relinker.MissingLibraryException r10 = new com.getkeepsafe.relinker.MissingLibraryException     // Catch:{ all -> 0x00a0 }
            r10.<init>(r11)     // Catch:{ all -> 0x00a0 }
            throw r10     // Catch:{ all -> 0x00a0 }
        L_0x00a0:
            r10 = move-exception
            r0 = r9
            goto L_0x00a4
        L_0x00a3:
            r10 = move-exception
        L_0x00a4:
            if (r0 == 0) goto L_0x00af
            java.util.zip.ZipFile r9 = r0.zipFile     // Catch:{ IOException -> 0x00af }
            if (r9 == 0) goto L_0x00af
            java.util.zip.ZipFile r9 = r0.zipFile     // Catch:{ IOException -> 0x00af }
            r9.close()     // Catch:{ IOException -> 0x00af }
        L_0x00af:
            throw r10
        */
        throw new UnsupportedOperationException("Method not decompiled: com.getkeepsafe.relinker.ApkLibraryInstaller.installLibrary(android.content.Context, java.lang.String[], java.lang.String, java.io.File, com.getkeepsafe.relinker.ReLinkerInstance):void");
    }

    private long copy(InputStream inputStream, OutputStream outputStream) throws IOException {
        byte[] bArr = new byte[4096];
        long j = 0;
        while (true) {
            int read = inputStream.read(bArr);
            if (read == -1) {
                outputStream.flush();
                return j;
            }
            outputStream.write(bArr, 0, read);
            j += (long) read;
        }
    }

    private void closeSilently(Closeable closeable) {
        if (closeable != null) {
            try {
                closeable.close();
            } catch (IOException unused) {
            }
        }
    }
}
