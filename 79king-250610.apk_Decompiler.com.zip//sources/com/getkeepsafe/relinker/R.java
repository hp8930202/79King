package com.getkeepsafe.relinker;

public final class R {
    private R() {
    }
}
