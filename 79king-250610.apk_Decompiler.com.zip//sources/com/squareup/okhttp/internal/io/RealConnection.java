package com.squareup.okhttp.internal.io;

import com.squareup.okhttp.Address;
import com.squareup.okhttp.Connection;
import com.squareup.okhttp.ConnectionSpec;
import com.squareup.okhttp.Handshake;
import com.squareup.okhttp.HttpUrl;
import com.squareup.okhttp.Protocol;
import com.squareup.okhttp.Request;
import com.squareup.okhttp.Response;
import com.squareup.okhttp.Route;
import com.squareup.okhttp.internal.ConnectionSpecSelector;
import com.squareup.okhttp.internal.Platform;
import com.squareup.okhttp.internal.Util;
import com.squareup.okhttp.internal.Version;
import com.squareup.okhttp.internal.framed.FramedConnection;
import com.squareup.okhttp.internal.http.Http1xStream;
import com.squareup.okhttp.internal.http.OkHeaders;
import com.squareup.okhttp.internal.http.RouteException;
import com.squareup.okhttp.internal.http.StreamAllocation;
import com.squareup.okhttp.internal.tls.TrustRootIndex;
import java.io.IOException;
import java.lang.ref.Reference;
import java.net.ConnectException;
import java.net.Proxy;
import java.net.Socket;
import java.net.SocketTimeoutException;
import java.net.UnknownServiceException;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;
import javax.net.ssl.SSLSocketFactory;
import kotlin.jvm.internal.LongCompanionObject;
import okio.BufferedSink;
import okio.BufferedSource;
import okio.Okio;
import okio.Source;

public final class RealConnection implements Connection {
    private static SSLSocketFactory lastSslSocketFactory;
    private static TrustRootIndex lastTrustRootIndex;
    public final List<Reference<StreamAllocation>> allocations = new ArrayList();
    public volatile FramedConnection framedConnection;
    private Handshake handshake;
    public long idleAtNanos = LongCompanionObject.MAX_VALUE;
    public boolean noNewStreams;
    private Protocol protocol;
    private Socket rawSocket;
    private final Route route;
    public BufferedSink sink;
    public Socket socket;
    public BufferedSource source;
    public int streamCount;

    public RealConnection(Route route2) {
        this.route = route2;
    }

    public void connect(int i, int i2, int i3, List<ConnectionSpec> list, boolean z) throws RouteException {
        Socket socket2;
        if (this.protocol == null) {
            ConnectionSpecSelector connectionSpecSelector = new ConnectionSpecSelector(list);
            Proxy proxy = this.route.getProxy();
            Address address = this.route.getAddress();
            if (this.route.getAddress().getSslSocketFactory() != null || list.contains(ConnectionSpec.CLEARTEXT)) {
                RouteException routeException = null;
                while (this.protocol == null) {
                    try {
                        if (proxy.type() != Proxy.Type.DIRECT) {
                            if (proxy.type() != Proxy.Type.HTTP) {
                                socket2 = new Socket(proxy);
                                this.rawSocket = socket2;
                                connectSocket(i, i2, i3, connectionSpecSelector);
                            }
                        }
                        socket2 = address.getSocketFactory().createSocket();
                        this.rawSocket = socket2;
                        connectSocket(i, i2, i3, connectionSpecSelector);
                    } catch (IOException e) {
                        Util.closeQuietly(this.socket);
                        Util.closeQuietly(this.rawSocket);
                        this.socket = null;
                        this.rawSocket = null;
                        this.source = null;
                        this.sink = null;
                        this.handshake = null;
                        this.protocol = null;
                        if (routeException == null) {
                            routeException = new RouteException(e);
                        } else {
                            routeException.addConnectException(e);
                        }
                        if (!z || !connectionSpecSelector.connectionFailed(e)) {
                            throw routeException;
                        }
                    }
                }
                return;
            }
            throw new RouteException(new UnknownServiceException("CLEARTEXT communication not supported: " + list));
        }
        throw new IllegalStateException("already connected");
    }

    private void connectSocket(int i, int i2, int i3, ConnectionSpecSelector connectionSpecSelector) throws IOException {
        this.rawSocket.setSoTimeout(i2);
        try {
            Platform.get().connectSocket(this.rawSocket, this.route.getSocketAddress(), i);
            this.source = Okio.buffer(Okio.source(this.rawSocket));
            this.sink = Okio.buffer(Okio.sink(this.rawSocket));
            if (this.route.getAddress().getSslSocketFactory() != null) {
                connectTls(i2, i3, connectionSpecSelector);
            } else {
                this.protocol = Protocol.HTTP_1_1;
                this.socket = this.rawSocket;
            }
            if (this.protocol == Protocol.SPDY_3 || this.protocol == Protocol.HTTP_2) {
                this.socket.setSoTimeout(0);
                FramedConnection build = new FramedConnection.Builder(true).socket(this.socket, this.route.getAddress().url().host(), this.source, this.sink).protocol(this.protocol).build();
                build.sendConnectionPreface();
                this.framedConnection = build;
            }
        } catch (ConnectException unused) {
            throw new ConnectException("Failed to connect to " + this.route.getSocketAddress());
        }
    }

    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r2v2, resolved type: java.lang.String} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r2v3, resolved type: javax.net.ssl.SSLSocket} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r2v4, resolved type: java.lang.String} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r9v6, resolved type: javax.net.ssl.SSLSocket} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r2v5, resolved type: java.lang.String} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r2v6, resolved type: javax.net.ssl.SSLSocket} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r2v9, resolved type: java.lang.String} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r2v11, resolved type: javax.net.ssl.SSLSocket} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r2v12, resolved type: java.lang.String} */
    /* JADX WARNING: Multi-variable type inference failed */
    /* JADX WARNING: Removed duplicated region for block: B:37:0x0123 A[Catch:{ all -> 0x011a }] */
    /* JADX WARNING: Removed duplicated region for block: B:39:0x0129 A[Catch:{ all -> 0x011a }] */
    /* JADX WARNING: Removed duplicated region for block: B:41:0x012c  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    private void connectTls(int r8, int r9, com.squareup.okhttp.internal.ConnectionSpecSelector r10) throws java.io.IOException {
        /*
            r7 = this;
            java.lang.String r0 = " not verified:\n    certificate: "
            java.lang.String r1 = "Hostname "
            com.squareup.okhttp.Route r2 = r7.route
            boolean r2 = r2.requiresTunnel()
            if (r2 == 0) goto L_0x000f
            r7.createTunnel(r8, r9)
        L_0x000f:
            com.squareup.okhttp.Route r8 = r7.route
            com.squareup.okhttp.Address r8 = r8.getAddress()
            javax.net.ssl.SSLSocketFactory r9 = r8.getSslSocketFactory()
            r2 = 0
            java.net.Socket r3 = r7.rawSocket     // Catch:{ AssertionError -> 0x011c }
            java.lang.String r4 = r8.getUriHost()     // Catch:{ AssertionError -> 0x011c }
            int r5 = r8.getUriPort()     // Catch:{ AssertionError -> 0x011c }
            r6 = 1
            java.net.Socket r9 = r9.createSocket(r3, r4, r5, r6)     // Catch:{ AssertionError -> 0x011c }
            javax.net.ssl.SSLSocket r9 = (javax.net.ssl.SSLSocket) r9     // Catch:{ AssertionError -> 0x011c }
            com.squareup.okhttp.ConnectionSpec r10 = r10.configureSecureSocket(r9)     // Catch:{ AssertionError -> 0x0117, all -> 0x0114 }
            boolean r3 = r10.supportsTlsExtensions()     // Catch:{ AssertionError -> 0x0117, all -> 0x0114 }
            if (r3 == 0) goto L_0x0044
            com.squareup.okhttp.internal.Platform r3 = com.squareup.okhttp.internal.Platform.get()     // Catch:{ AssertionError -> 0x0117, all -> 0x0114 }
            java.lang.String r4 = r8.getUriHost()     // Catch:{ AssertionError -> 0x0117, all -> 0x0114 }
            java.util.List r5 = r8.getProtocols()     // Catch:{ AssertionError -> 0x0117, all -> 0x0114 }
            r3.configureTlsExtensions(r9, r4, r5)     // Catch:{ AssertionError -> 0x0117, all -> 0x0114 }
        L_0x0044:
            r9.startHandshake()     // Catch:{ AssertionError -> 0x0117, all -> 0x0114 }
            javax.net.ssl.SSLSession r3 = r9.getSession()     // Catch:{ AssertionError -> 0x0117, all -> 0x0114 }
            com.squareup.okhttp.Handshake r3 = com.squareup.okhttp.Handshake.get(r3)     // Catch:{ AssertionError -> 0x0117, all -> 0x0114 }
            javax.net.ssl.HostnameVerifier r4 = r8.getHostnameVerifier()     // Catch:{ AssertionError -> 0x0117, all -> 0x0114 }
            java.lang.String r5 = r8.getUriHost()     // Catch:{ AssertionError -> 0x0117, all -> 0x0114 }
            javax.net.ssl.SSLSession r6 = r9.getSession()     // Catch:{ AssertionError -> 0x0117, all -> 0x0114 }
            boolean r4 = r4.verify(r5, r6)     // Catch:{ AssertionError -> 0x0117, all -> 0x0114 }
            if (r4 == 0) goto L_0x00c6
            com.squareup.okhttp.CertificatePinner r0 = r8.getCertificatePinner()     // Catch:{ AssertionError -> 0x0117, all -> 0x0114 }
            com.squareup.okhttp.CertificatePinner r1 = com.squareup.okhttp.CertificatePinner.DEFAULT     // Catch:{ AssertionError -> 0x0117, all -> 0x0114 }
            if (r0 == r1) goto L_0x0089
            javax.net.ssl.SSLSocketFactory r0 = r8.getSslSocketFactory()     // Catch:{ AssertionError -> 0x0117, all -> 0x0114 }
            com.squareup.okhttp.internal.tls.TrustRootIndex r0 = trustRootIndex(r0)     // Catch:{ AssertionError -> 0x0117, all -> 0x0114 }
            com.squareup.okhttp.internal.tls.CertificateChainCleaner r1 = new com.squareup.okhttp.internal.tls.CertificateChainCleaner     // Catch:{ AssertionError -> 0x0117, all -> 0x0114 }
            r1.<init>(r0)     // Catch:{ AssertionError -> 0x0117, all -> 0x0114 }
            java.util.List r0 = r3.peerCertificates()     // Catch:{ AssertionError -> 0x0117, all -> 0x0114 }
            java.util.List r0 = r1.clean(r0)     // Catch:{ AssertionError -> 0x0117, all -> 0x0114 }
            com.squareup.okhttp.CertificatePinner r1 = r8.getCertificatePinner()     // Catch:{ AssertionError -> 0x0117, all -> 0x0114 }
            java.lang.String r8 = r8.getUriHost()     // Catch:{ AssertionError -> 0x0117, all -> 0x0114 }
            r1.check((java.lang.String) r8, (java.util.List<java.security.cert.Certificate>) r0)     // Catch:{ AssertionError -> 0x0117, all -> 0x0114 }
        L_0x0089:
            boolean r8 = r10.supportsTlsExtensions()     // Catch:{ AssertionError -> 0x0117, all -> 0x0114 }
            if (r8 == 0) goto L_0x0097
            com.squareup.okhttp.internal.Platform r8 = com.squareup.okhttp.internal.Platform.get()     // Catch:{ AssertionError -> 0x0117, all -> 0x0114 }
            java.lang.String r2 = r8.getSelectedProtocol(r9)     // Catch:{ AssertionError -> 0x0117, all -> 0x0114 }
        L_0x0097:
            r7.socket = r9     // Catch:{ AssertionError -> 0x0117, all -> 0x0114 }
            okio.Source r8 = okio.Okio.source((java.net.Socket) r9)     // Catch:{ AssertionError -> 0x0117, all -> 0x0114 }
            okio.BufferedSource r8 = okio.Okio.buffer((okio.Source) r8)     // Catch:{ AssertionError -> 0x0117, all -> 0x0114 }
            r7.source = r8     // Catch:{ AssertionError -> 0x0117, all -> 0x0114 }
            java.net.Socket r8 = r7.socket     // Catch:{ AssertionError -> 0x0117, all -> 0x0114 }
            okio.Sink r8 = okio.Okio.sink((java.net.Socket) r8)     // Catch:{ AssertionError -> 0x0117, all -> 0x0114 }
            okio.BufferedSink r8 = okio.Okio.buffer((okio.Sink) r8)     // Catch:{ AssertionError -> 0x0117, all -> 0x0114 }
            r7.sink = r8     // Catch:{ AssertionError -> 0x0117, all -> 0x0114 }
            r7.handshake = r3     // Catch:{ AssertionError -> 0x0117, all -> 0x0114 }
            if (r2 == 0) goto L_0x00b8
            com.squareup.okhttp.Protocol r8 = com.squareup.okhttp.Protocol.get(r2)     // Catch:{ AssertionError -> 0x0117, all -> 0x0114 }
            goto L_0x00ba
        L_0x00b8:
            com.squareup.okhttp.Protocol r8 = com.squareup.okhttp.Protocol.HTTP_1_1     // Catch:{ AssertionError -> 0x0117, all -> 0x0114 }
        L_0x00ba:
            r7.protocol = r8     // Catch:{ AssertionError -> 0x0117, all -> 0x0114 }
            if (r9 == 0) goto L_0x00c5
            com.squareup.okhttp.internal.Platform r8 = com.squareup.okhttp.internal.Platform.get()
            r8.afterHandshake(r9)
        L_0x00c5:
            return
        L_0x00c6:
            java.util.List r10 = r3.peerCertificates()     // Catch:{ AssertionError -> 0x0117, all -> 0x0114 }
            r2 = 0
            java.lang.Object r10 = r10.get(r2)     // Catch:{ AssertionError -> 0x0117, all -> 0x0114 }
            java.security.cert.X509Certificate r10 = (java.security.cert.X509Certificate) r10     // Catch:{ AssertionError -> 0x0117, all -> 0x0114 }
            javax.net.ssl.SSLPeerUnverifiedException r2 = new javax.net.ssl.SSLPeerUnverifiedException     // Catch:{ AssertionError -> 0x0117, all -> 0x0114 }
            java.lang.StringBuilder r3 = new java.lang.StringBuilder     // Catch:{ AssertionError -> 0x0117, all -> 0x0114 }
            r3.<init>(r1)     // Catch:{ AssertionError -> 0x0117, all -> 0x0114 }
            java.lang.String r8 = r8.getUriHost()     // Catch:{ AssertionError -> 0x0117, all -> 0x0114 }
            java.lang.StringBuilder r8 = r3.append(r8)     // Catch:{ AssertionError -> 0x0117, all -> 0x0114 }
            java.lang.StringBuilder r8 = r8.append(r0)     // Catch:{ AssertionError -> 0x0117, all -> 0x0114 }
            java.lang.String r0 = com.squareup.okhttp.CertificatePinner.pin(r10)     // Catch:{ AssertionError -> 0x0117, all -> 0x0114 }
            java.lang.StringBuilder r8 = r8.append(r0)     // Catch:{ AssertionError -> 0x0117, all -> 0x0114 }
            java.lang.String r0 = "\n    DN: "
            java.lang.StringBuilder r8 = r8.append(r0)     // Catch:{ AssertionError -> 0x0117, all -> 0x0114 }
            java.security.Principal r0 = r10.getSubjectDN()     // Catch:{ AssertionError -> 0x0117, all -> 0x0114 }
            java.lang.String r0 = r0.getName()     // Catch:{ AssertionError -> 0x0117, all -> 0x0114 }
            java.lang.StringBuilder r8 = r8.append(r0)     // Catch:{ AssertionError -> 0x0117, all -> 0x0114 }
            java.lang.String r0 = "\n    subjectAltNames: "
            java.lang.StringBuilder r8 = r8.append(r0)     // Catch:{ AssertionError -> 0x0117, all -> 0x0114 }
            java.util.List r10 = com.squareup.okhttp.internal.tls.OkHostnameVerifier.allSubjectAltNames(r10)     // Catch:{ AssertionError -> 0x0117, all -> 0x0114 }
            java.lang.StringBuilder r8 = r8.append(r10)     // Catch:{ AssertionError -> 0x0117, all -> 0x0114 }
            java.lang.String r8 = r8.toString()     // Catch:{ AssertionError -> 0x0117, all -> 0x0114 }
            r2.<init>(r8)     // Catch:{ AssertionError -> 0x0117, all -> 0x0114 }
            throw r2     // Catch:{ AssertionError -> 0x0117, all -> 0x0114 }
        L_0x0114:
            r8 = move-exception
            r2 = r9
            goto L_0x012a
        L_0x0117:
            r8 = move-exception
            r2 = r9
            goto L_0x011d
        L_0x011a:
            r8 = move-exception
            goto L_0x012a
        L_0x011c:
            r8 = move-exception
        L_0x011d:
            boolean r9 = com.squareup.okhttp.internal.Util.isAndroidGetsocknameError(r8)     // Catch:{ all -> 0x011a }
            if (r9 == 0) goto L_0x0129
            java.io.IOException r9 = new java.io.IOException     // Catch:{ all -> 0x011a }
            r9.<init>(r8)     // Catch:{ all -> 0x011a }
            throw r9     // Catch:{ all -> 0x011a }
        L_0x0129:
            throw r8     // Catch:{ all -> 0x011a }
        L_0x012a:
            if (r2 == 0) goto L_0x0133
            com.squareup.okhttp.internal.Platform r9 = com.squareup.okhttp.internal.Platform.get()
            r9.afterHandshake(r2)
        L_0x0133:
            com.squareup.okhttp.internal.Util.closeQuietly((java.net.Socket) r2)
            throw r8
        */
        throw new UnsupportedOperationException("Method not decompiled: com.squareup.okhttp.internal.io.RealConnection.connectTls(int, int, com.squareup.okhttp.internal.ConnectionSpecSelector):void");
    }

    private static synchronized TrustRootIndex trustRootIndex(SSLSocketFactory sSLSocketFactory) {
        TrustRootIndex trustRootIndex;
        synchronized (RealConnection.class) {
            if (sSLSocketFactory != lastSslSocketFactory) {
                lastTrustRootIndex = Platform.get().trustRootIndex(Platform.get().trustManager(sSLSocketFactory));
                lastSslSocketFactory = sSLSocketFactory;
            }
            trustRootIndex = lastTrustRootIndex;
        }
        return trustRootIndex;
    }

    private void createTunnel(int i, int i2) throws IOException {
        Request createTunnelRequest = createTunnelRequest();
        HttpUrl httpUrl = createTunnelRequest.httpUrl();
        String str = "CONNECT " + httpUrl.host() + ":" + httpUrl.port() + " HTTP/1.1";
        do {
            Http1xStream http1xStream = new Http1xStream((StreamAllocation) null, this.source, this.sink);
            this.source.timeout().timeout((long) i, TimeUnit.MILLISECONDS);
            this.sink.timeout().timeout((long) i2, TimeUnit.MILLISECONDS);
            http1xStream.writeRequest(createTunnelRequest.headers(), str);
            http1xStream.finishRequest();
            Response build = http1xStream.readResponse().request(createTunnelRequest).build();
            long contentLength = OkHeaders.contentLength(build);
            if (contentLength == -1) {
                contentLength = 0;
            }
            Source newFixedLengthSource = http1xStream.newFixedLengthSource(contentLength);
            Util.skipAll(newFixedLengthSource, Integer.MAX_VALUE, TimeUnit.MILLISECONDS);
            newFixedLengthSource.close();
            int code = build.code();
            if (code != 200) {
                if (code == 407) {
                    createTunnelRequest = OkHeaders.processAuthHeader(this.route.getAddress().getAuthenticator(), build, this.route.getProxy());
                } else {
                    throw new IOException("Unexpected response code for CONNECT: " + build.code());
                }
            } else if (!this.source.buffer().exhausted() || !this.sink.buffer().exhausted()) {
                throw new IOException("TLS tunnel buffered too many bytes!");
            } else {
                return;
            }
        } while (createTunnelRequest != null);
        throw new IOException("Failed to authenticate with proxy");
    }

    private Request createTunnelRequest() throws IOException {
        return new Request.Builder().url(this.route.getAddress().url()).header("Host", Util.hostHeader(this.route.getAddress().url())).header("Proxy-Connection", "Keep-Alive").header("User-Agent", Version.userAgent()).build();
    }

    /* access modifiers changed from: package-private */
    public boolean isConnected() {
        return this.protocol != null;
    }

    public Route getRoute() {
        return this.route;
    }

    public void cancel() {
        Util.closeQuietly(this.rawSocket);
    }

    public Socket getSocket() {
        return this.socket;
    }

    public int allocationLimit() {
        FramedConnection framedConnection2 = this.framedConnection;
        if (framedConnection2 != null) {
            return framedConnection2.maxConcurrentStreams();
        }
        return 1;
    }

    public boolean isHealthy(boolean z) {
        int soTimeout;
        if (this.socket.isClosed() || this.socket.isInputShutdown() || this.socket.isOutputShutdown()) {
            return false;
        }
        if (this.framedConnection == null && z) {
            try {
                soTimeout = this.socket.getSoTimeout();
                this.socket.setSoTimeout(1);
                if (this.source.exhausted()) {
                    this.socket.setSoTimeout(soTimeout);
                    return false;
                }
                this.socket.setSoTimeout(soTimeout);
                return true;
            } catch (SocketTimeoutException unused) {
            } catch (IOException unused2) {
                return false;
            } catch (Throwable th) {
                this.socket.setSoTimeout(soTimeout);
                throw th;
            }
        }
        return true;
    }

    public Handshake getHandshake() {
        return this.handshake;
    }

    public boolean isMultiplexed() {
        return this.framedConnection != null;
    }

    public Protocol getProtocol() {
        Protocol protocol2 = this.protocol;
        return protocol2 != null ? protocol2 : Protocol.HTTP_1_1;
    }

    public String toString() {
        StringBuilder append = new StringBuilder("Connection{").append(this.route.getAddress().url().host()).append(":").append(this.route.getAddress().url().port()).append(", proxy=").append(this.route.getProxy()).append(" hostAddress=").append(this.route.getSocketAddress()).append(" cipherSuite=");
        Handshake handshake2 = this.handshake;
        return append.append(handshake2 != null ? handshake2.cipherSuite() : "none").append(" protocol=").append(this.protocol).append('}').toString();
    }
}
